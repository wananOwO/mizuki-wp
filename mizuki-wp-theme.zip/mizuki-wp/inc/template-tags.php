<?php
/**
 * 模板辅助函数。
 *
 * @package Mizuki
 */
defined( 'ABSPATH' ) || exit;

/**
 * 估算当前文章阅读时间(分钟,按 ~300 中文字/分钟)。
 *
 * @param int|null $post_id 文章 ID,默认当前文章。
 * @return int 阅读分钟数(至少 1)。
 */
function mizuki_reading_time( $post_id = null ) {
	$content = get_post_field( 'post_content', $post_id ?: get_the_ID() );
	$count   = mizuki_count_content_characters( $content );
	return max( 1, (int) ceil( $count / 300 ) );
}

/**
 * Count visible, non-whitespace characters in post content.
 *
 * @param string $content Post content, which may contain HTML.
 * @return int Character count.
 */
function mizuki_count_content_characters( $content ) {
	$text = wp_strip_all_tags( $content );
	$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$text = preg_replace( '/[\s\p{Z}]+/u', '', $text );

	if ( null === $text ) {
		return 0;
	}

	$count = preg_match_all( '/./us', $text, $characters );

	return false === $count ? strlen( $text ) : $count;
}

/**
 * Count characters in a post.
 *
 * @param int|null $post_id Post ID; defaults to the current post.
 * @return int Character count.
 */
function mizuki_word_count( $post_id = null ) {
	$content = get_post_field( 'post_content', $post_id ?: get_the_ID() );

	return mizuki_count_content_characters( $content );
}

/**
 * 分类筛选标签(project_category / skill_category / timeline_type)的默认显示名映射。
 *
 * 这些是各模板原先硬编码的默认值,迁出来集中维护,作为 theme_mod 覆盖的回退基线。
 *
 * @param string $taxonomy 'project_category', 'skill_category' 或 'timeline_type'。
 * @return array slug => 显示名。
 */
function mizuki_default_category_labels( $taxonomy ) {
	$defaults = array(
		'project_category' => array(
			'web'     => 'Web',
			'mobile'  => '移动端',
			'desktop' => '桌面端',
			'other'   => '其他',
		),
		'skill_category'   => array(
			'frontend' => '前端',
			'backend'  => '后端',
			'database' => '数据库',
			'tools'    => '工具',
			'other'    => '其他',
		),
		'timeline_type'    => array(
			'education'   => '教育',
			'work'        => '工作',
			'project'     => '项目',
			'achievement' => '成就',
		),
	);
	return isset( $defaults[ $taxonomy ] ) ? $defaults[ $taxonomy ] : array();
}

/**
 * 分类筛选标签的默认图标映射(内联 SVG 字符串,直接 echo 到筛选 Tab)。
 *
 * @param string $taxonomy 'project_category', 'skill_category' 或 'timeline_type'。
 * @return array slug => 内联 SVG 字符串。键 'other' 必定存在,作为未知 slug 的回退。
 */
function mizuki_default_category_icons( $taxonomy ) {
	$svg_other = '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M12 2l-5.5 9h11L12 2zm0 3.84L13.93 9h-3.87L12 5.84zM17.5 13c-2.49 0-4.5 2.01-4.5 4.5s2.01 4.5 4.5 4.5 4.5-2.01 4.5-4.5-2.01-4.5-4.5-4.5zm0 7c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5zM3 21.5h8v-8H3v8zm2-6h4v4H5v-4z"/></svg>';
	$defaults = array(
		'project_category' => array(
			'web'     => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>',
			'mobile'  => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>',
			'desktop' => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M21 2H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h7v2H8v2h8v-2h-2v-2h7c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H3V4h18v12z"/></svg>',
			'other'   => $svg_other,
		),
		'skill_category'   => array(
			'frontend' => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>',
			'backend'  => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M20 13H4c-.55 0-1 .45-1 1v6c0 .55.45 1 1 1h16c.55 0 1-.45 1-1v-6c0-.55-.45-1-1-1zM7 19c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zM20 3H4c-.55 0-1 .45-1 1v6c0 .55.45 1 1 1h16c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zM7 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/></svg>',
			'database' => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M2 20h20v-4H2v4zm2-3h2v2H4v-2zM2 4v4h20V4H2zm4 3H4V5h2v2zm-4 7h20v-4H2v4zm2-3h2v2H4v-2z"/></svg>',
			'tools'    => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/></svg>',
			'other'    => $svg_other,
		),
		'timeline_type'    => array(
			'education'   => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z"/></svg>',
			'work'        => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/></svg>',
			'project'     => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/></svg>',
			'achievement' => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M19 5h-2V3H7v2H5c-1.1 0-2 .9-2 2v1c0 2.55 1.92 4.63 4.39 4.94.63 1.5 1.98 2.63 3.61 2.96V19H7v2h10v-2h-4v-3.1c1.63-.33 2.98-1.46 3.61-2.96C19.08 12.63 21 10.55 21 8V7c0-1.1-.9-2-2-2zM5 8V7h2v3.82C5.84 10.4 5 9.3 5 8zm14 0c0 1.3-.84 2.4-2 2.82V7h2v1z"/></svg>',
		),
	);
	return isset( $defaults[ $taxonomy ] ) ? $defaults[ $taxonomy ] : array( 'other' => $svg_other );
}

/**
 * 取得分类显示名映射:theme_mod 覆盖叠加在硬编码默认值之上。
 *
 * theme_mod 键名:mizuki_{taxonomy}_labels(slug => 显示名 的关联数组)。
 *
 * @param string $taxonomy 'project_category' 或 'skill_category'。
 * @return array slug => 显示名。
 */
function mizuki_get_category_labels( $taxonomy ) {
	$defaults = mizuki_default_category_labels( $taxonomy );
	$override = get_theme_mod( 'mizuki_' . $taxonomy . '_labels', array() );
	if ( ! is_array( $override ) ) {
		$override = array();
	}
	return array_merge( $defaults, $override );
}

/**
 * 取得分类图标映射:theme_mod 覆盖叠加在硬编码默认值之上。
 *
 * theme_mod 键名:mizuki_{taxonomy}_icons(slug => 内联 SVG 的关联数组)。
 *
 * @param string $taxonomy 'project_category' 或 'skill_category'。
 * @return array slug => 内联 SVG 字符串(必含 'other' 回退键)。
 */
function mizuki_get_category_icons( $taxonomy ) {
	$icons    = mizuki_default_category_icons( $taxonomy );
	$override = get_theme_mod( 'mizuki_' . $taxonomy . '_icons', array() );
	if ( ! is_array( $override ) ) {
		$override = array();
	}
	// 控制台里用户填写的是图标 class(如 devicon-html5-plain,与 _mizuki_skill_icon 字段一致),
	// 这里转成可直接 echo 的 <i> HTML,保持模板"echo 映射值"的统一契约。
	foreach ( $override as $slug => $icon_class ) {
		$icon_class = trim( (string) $icon_class );
		if ( '' === $icon_class ) {
			continue;
		}
		$icons[ $slug ] = '<i class="' . esc_attr( $icon_class ) . ' text-base w-4 h-4"></i>';
	}
	return $icons;
}

/**
 * 输出分类筛选条(category-bar):Home + 归档 + 各分类胶囊。
 * 与原版 Mizuki 首页主内容区上方的 #category-bar 一致。
 */
function mizuki_category_bar() {
	$cats = get_categories( array( 'hide_empty' => true, 'number' => 30 ) );
	if ( ! $cats ) {
		return;
	}
	$archive_url   = get_permalink( get_option( 'page_for_posts' ) );
	if ( ! $archive_url ) {
		$archive_url = home_url( '/' );
	}
	$total         = (int) wp_count_posts()->publish;
	$current_cat   = is_category() ? (int) get_queried_object_id() : 0;
	$home_active   = ( is_home() || is_front_page() ) ? ' data-active' : '';
	$home_icon     = '<svg width="1em" height="1em" viewBox="0 0 24 24" class="text-lg"><path fill="currentColor" d="M4 21V9l8-6l8 6v12h-6v-7h-4v7z"/></svg>';
	?>
	<div class="card-base category-bar p-3 onload-animation" id="category-bar">
		<div class="category-bar-inner flex gap-2">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="category-pill text-sm px-2 py-1 rounded-lg flex-shrink-0 transition-colors duration-200 flex items-center justify-center" aria-label="<?php esc_attr_e( '首页', 'mizuki' ); ?>"<?php echo $home_active; // phpcs:ignore ?>><?php echo $home_icon; // phpcs:ignore ?></a>
			<a href="<?php echo esc_url( $archive_url ); ?>" class="category-pill text-sm px-3 py-1 rounded-lg whitespace-nowrap flex-shrink-0 transition-colors duration-200 flex items-center justify-center"><?php esc_html_e( '归档', 'mizuki' ); ?> <span class="text-xs opacity-60 ml-1"><?php echo (int) $total; ?></span></a>
			<div class="category-divider flex-shrink-0"></div>
			<div class="category-scroll flex gap-2 overflow-x-auto min-w-0 flex-1">
				<?php foreach ( $cats as $cat ) : ?>
				<a href="<?php echo esc_url( get_category_link( $cat ) ); ?>" class="category-pill text-sm px-3 py-1 rounded-lg whitespace-nowrap transition-colors duration-200 flex items-center justify-center"<?php echo ( $current_cat === (int) $cat->term_id ) ? ' data-active' : ''; ?>><?php echo esc_html( $cat->name ); ?> <span class="text-xs opacity-60 ml-1"><?php echo (int) $cat->count; ?></span></a>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<?php
}

/**
 * 时间线辅助函数
 */

/**
 * 获取时间线类型的默认图标（SVG HTML）
 */
function mizuki_get_default_type_icon( $type_slug ) {
	$icons = array(
		'education'   => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z"/></svg>',
		'work'        => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/></svg>',
		'project'     => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/></svg>',
		'achievement' => '<svg viewBox="0 0 24 24" width="1em" height="1em" class="text-base w-4 h-4"><path fill="currentColor" d="M19 5h-2V3H7v2H5c-1.1 0-2 .9-2 2v1c0 2.55 1.92 4.63 4.39 4.94.63 1.5 1.98 2.63 3.61 2.96V19H7v2h10v-2h-4v-3.1c1.63-.33 2.98-1.46 3.61-2.96C19.08 12.63 21 10.55 21 8V7c0-1.1-.9-2-2-2zM5 8V7h2v3.82C5.84 10.4 5 9.3 5 8zm14 0c0 1.3-.84 2.4-2 2.82V7h2v1z"/></svg>',
	);
	return isset( $icons[ $type_slug ] ) ? $icons[ $type_slug ] : $icons['achievement'];
}

/**
 * 获取时间线类型的默认图标 class（用于 Iconify）
 */
function mizuki_get_default_type_icon_class( $type_slug ) {
	$icons = array(
		'education'   => 'material-symbols:school',
		'work'        => 'material-symbols:work',
		'project'     => 'material-symbols:code',
		'achievement' => 'material-symbols:emoji-events',
	);
	return isset( $icons[ $type_slug ] ) ? $icons[ $type_slug ] : 'material-symbols:emoji-events';
}

/**
 * 获取时间线类型的默认颜色
 */
function mizuki_get_default_type_color( $type_slug ) {
	$colors = array(
		'education'   => '#2563EB', // 蓝色
		'work'        => '#DC2626', // 红色
		'project'     => '#7C3AED', // 紫色
		'achievement' => '#059669', // 绿色
	);
	return isset( $colors[ $type_slug ] ) ? $colors[ $type_slug ] : '#7C3AED';
}

/**
 * 格式化日期范围
 */
function mizuki_format_date_range( $start_date, $end_date = '' ) {
	if ( empty( $start_date ) ) {
		return '';
	}

	$start = date_i18n( 'Y年n月', strtotime( $start_date ) );
	if ( empty( $end_date ) ) {
		return $start . ' - 至今';
	}

	$end = date_i18n( 'Y年n月', strtotime( $end_date ) );
	return $start . ' - ' . $end;
}

/**
 * 计算时长（月数/年数）
 */
function mizuki_calculate_duration( $start_date, $end_date = '' ) {
	if ( empty( $start_date ) ) {
		return '';
	}

	$start = new DateTime( $start_date );
	$end   = empty( $end_date ) ? new DateTime() : new DateTime( $end_date );

	$interval = $start->diff( $end );
	$months   = $interval->y * 12 + $interval->m;

	if ( $months < 12 ) {
		return $months . ' 个月';
	}

	$years        = floor( $months / 12 );
	$remain_months = $months % 12;

	if ( $remain_months === 0 ) {
		return $years . ' 年';
	}

	return $years . ' 年 ' . $remain_months . ' 个月';
}

/**
 * 获取链接类型图标
 */
function mizuki_get_link_type_icon( $type ) {
	$icons = array(
		'certificate' => '<svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg>',
		'project'     => '<svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>',
		'website'     => '<svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>',
		'other'       => '<svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>',
	);
	return isset( $icons[ $type ] ) ? $icons[ $type ] : $icons['other'];
}

/**
 * 渲染页面标题区（标题 + 描述 + 分隔线）。
 *
 * @param array $args { title, description, show_divider }.
 */
function mizuki_page_header( $args = array() ) {
	$args = wp_parse_args( $args, array(
		'title'        => '',
		'description'  => '',
		'show_divider' => true,
	) );
	if ( $args['title'] ) {
		echo '<h1 class="transition w-full block font-bold mb-2 text-3xl md:text-4xl text-90">' . esc_html( $args['title'] ) . '</h1>';
	}
	if ( $args['description'] ) {
		echo '<p class="text-black/50 dark:text-white/50 mb-6">' . esc_html( $args['description'] ) . '</p>';
	}
	if ( $args['show_divider'] ) {
		echo '<div class="mt-4 border-[var(--line-divider)] border-dashed border-b-[1px] mb-6"></div>';
	}
}

/**
 * 渲染空状态提示。
 *
 * @param string $message 提示文案（已翻译）。
 */
function mizuki_empty_state( $message ) {
	echo '<p class="text-50 text-center py-12">' . esc_html( $message ) . '</p>';
}
